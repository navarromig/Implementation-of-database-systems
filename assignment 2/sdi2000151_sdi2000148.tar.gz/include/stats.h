int HashStatistics(char*);
